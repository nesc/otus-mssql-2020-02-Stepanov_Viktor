﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public class UserDefinedFunctions
{
    [SqlFunction(FillRowMethodName = "CheckPasportFillRow")]
    public static SqlString CheckPasport(SqlDateTime DateBirth, SqlDateTime DatePassport, SqlDateTime DateCheck)
    {
        var yearsAtPassportDate = DatePassport.Value.Year - DateBirth.Value.Year;
        var yearsAtCheckDate = DateCheck.Value.Year - DateBirth.Value.Year;


        if (yearsAtPassportDate < 20)
        {
            if (yearsAtCheckDate < 20)
            {
                return new SqlString("Действует");
            }
            if (yearsAtCheckDate >= 20)
            {
                return new SqlString("Не действует");
            }
        }

        if (yearsAtPassportDate >= 20 && yearsAtPassportDate < 45)
        {
            if (yearsAtCheckDate >= 20 && yearsAtCheckDate < 45)
            {
                return new SqlString("Действует");
            }
            if (yearsAtCheckDate >= 45)
            {
                return new SqlString("Не действует");
            }
        }

        if (yearsAtPassportDate > 45)
        {
            return new SqlString("Действует");
        }
        
        return new SqlString("Действует");
        
    }
    public static void FillRow(SqlDateTime DateBirth, SqlDateTime DatePassport, SqlDateTime DateCheck, out SqlString str)
    {
        str = CheckPasport(DateBirth, DatePassport, DateCheck);
    }
}
