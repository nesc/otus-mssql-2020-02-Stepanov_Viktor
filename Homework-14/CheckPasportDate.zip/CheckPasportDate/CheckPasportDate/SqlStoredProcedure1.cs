﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public class UserDefinedFunctions
{
    [SqlFunction(FillRowMethodName = "FillRow", TableDefinition = "string NVARCHAR(MAX)")]
    public static IEnumerable CheckPasport(SqlDateTime DateB, SqlDateTime DateP, SqlDateTime DateC)
    {
        
        int y1;
        int y2;

        y1 = DateP.Value.Year - DateB.Value.Year; //Сколько лет на дачу выдачи паспорта
        y2 = DateC.Value.Year - DateB.Value.Year; //Сколько лет на дату проверки
        

        //return y1.ToString();

        
        if (y1 < 20)
        {
            if (y2 < 20)
            {
                yield return new SqlString("Действует");
            }
            if (y2 >= 20)
            {
                yield return new SqlString("Не действует");
            }
        }

        if (y1 >= 20 && y1 < 45)
        {
            if (y2 >= 20 && y2 < 45)
            {
                yield return new SqlString("Действует");
            }
            if (y2 >= 45)
            {
                yield return new SqlString("Не действует");
            }
        }

        if (y1 > 45)
        {
            yield return new SqlString("Действует");
        }
        
    }
    public static void FillRow(object row, out SqlString str)
    {
        str = ""; // new SqlString((string)row);
    }
}
